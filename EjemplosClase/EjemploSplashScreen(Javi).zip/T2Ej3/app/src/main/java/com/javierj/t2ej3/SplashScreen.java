package com.javierj.t2ej3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SplashScreen extends AppCompatActivity {

    ProgressBar pg;
    int progreso;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        pg= findViewById(R.id.progreso);

    //Manera facil manejador de eventos
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashScreen.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        },1000);
    /*

    modo usando threads
        Thread hilo = new Thread(new Runnable() {
            @Override
            public void run() {
                ventana();
                next();

            }
        });

        hilo.start();
    }

    public void ventana (){
        for (progreso=20; progreso<=100; progreso=progreso+10){ //porcentaje de progreso
            try{
                Thread.sleep(500);                               //dormimos el thread para que progrese
                pg.setProgress(progreso);

            }catch(InterruptedException e){
                throw new RuntimeException(e);
            }
        }
    }

    public void next(){
        Intent intent = new Intent(SplashScreen.this, MainActivity.class); //utilizamos un intent
        startActivity(intent);
        finish();
    }*/
    }
}