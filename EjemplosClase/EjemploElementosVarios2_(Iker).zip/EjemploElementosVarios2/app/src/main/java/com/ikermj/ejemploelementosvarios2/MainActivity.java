package com.ikermj.ejemploelementosvarios2;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Switch interruptor = findViewById(R.id.switch1);

        //RadioButton
        RadioGroup panel = findViewById(R.id.panelRBtn);
        //SeekBar
        SeekBar seek = findViewById(R.id.seekBar);
        TextView texto = findViewById(R.id.texto);
        //RatingBar
        RatingBar estrellas = findViewById(R.id.ratingBar);

        //Se limpia el panel para que no salga nada marcado por defecto
        panel.clearCheck();
        //Utilizamos el escuchador asociado al boton tipo RadioButton
        //En este caso se asocia al panel
        panel.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbtnA) {
                    //Ponemos visible el switch
                    interruptor.setVisibility(View.VISIBLE);
                    //Ponemos invisible la seekBar, el textView y el ratingBar
                    seek.setVisibility(View.INVISIBLE);
                    texto.setVisibility(View.INVISIBLE);
                    estrellas.setVisibility(View.INVISIBLE);
                } else if (checkedId == R.id.rbtnB) {
                    //Ponemos visible la seekBar y el textView
                    seek.setVisibility(View.VISIBLE);
                    texto.setVisibility(View.VISIBLE);
                    //Ponemos invisible el switch y el ratingBar
                    interruptor.setVisibility(View.INVISIBLE);
                    estrellas.setVisibility(View.INVISIBLE);
                } else {
                    //Ponemos visible el ratingBar
                    estrellas.setVisibility(View.VISIBLE);
                    //Ponemos invisible el switch, la seekBar y el textView
                    interruptor.setVisibility(View.INVISIBLE);
                    seek.setVisibility(View.INVISIBLE);
                    texto.setVisibility(View.INVISIBLE);
                }
            }
        });

        //Crear el elemento asociado al Switch
        interruptor.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    interruptor.setTextColor(getResources().getColor(R.color.verde));
                } else {
                    interruptor.setTextColor(getResources().getColor(R.color.rojo));
                }
            }
        });

        //SeekBar evento asociado
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                texto.setText(String.valueOf(progress+"/100"));
                texto.setVisibility(View.VISIBLE);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                texto.setVisibility(View.INVISIBLE);
            }
        });

        //RatingBar
        estrellas.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                //Toast -> Mensajes informativos emergentes
                Toast.makeText(MainActivity.this, "Has votado con una puntuacion de: "+rating, Toast.LENGTH_LONG).show();
            }
        });

    }

}
