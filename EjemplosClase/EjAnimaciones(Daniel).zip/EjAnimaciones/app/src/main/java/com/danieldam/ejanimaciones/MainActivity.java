package com.danieldam.ejanimaciones;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Creamos una etiqueta tipo TextView
        TextView etiqueta=findViewById(R.id.etiquetaHola);

        //Creamos la animacion e importamos las clases
            //traslacion horizontal
        Animation traslacion = AnimationUtils.loadAnimation(this, R.anim.horizontal);
            //traslacion vertical
        Animation traslacionVertical = AnimationUtils.loadAnimation(this, R.anim.vertical);
            //giro 180
        Animation giro = AnimationUtils.loadAnimation(this, R.anim.giro);
            //aparicion
        Animation aparicion = AnimationUtils.loadAnimation(this, R.anim.aparicion);
            //escala
        Animation escala = AnimationUtils.loadAnimation(this, R.anim.escala);

        //Tipo de repeticion
            //traslacion horizontal
        traslacion.setRepeatMode(Animation.RESTART);
            //traslacion vertical
        traslacionVertical.setRepeatMode(Animation.RESTART);
            //giro 180
        giro.setRepeatMode(Animation.RESTART);
            //aparicion
        aparicion.setRepeatMode(Animation.RESTART);
            //escala
        escala.setRepeatMode(Animation.RESTART);

        //numero de veces que quiero que se repita
            //traslacion horizontal
        traslacion.setRepeatCount(20);
            //traslacion vertical
        traslacionVertical.setRepeatCount(20);
            //giro 180
        giro.setRepeatCount(20);
            //aparicion
        aparicion.setRepeatCount(20);
            //escala
        escala.setRepeatMode(20);

        //Cuando acabe la animacion el objeto no vuelve a su posicion original
            //traslacion horizontal
        traslacion.setFillAfter(true);
            //traslacion vertical
        traslacionVertical.setFillAfter(true);
            //giro 180
        giro.setFillAfter(true);
            //aparicion
        aparicion.setFillAfter(true);
            //escala
        escala.setFillAfter(false);

        //Iniciamos la animacion asociada a la etiqueta de texto
        //etiqueta.startAnimation(traslacion);
        //etiqueta.startAnimation(traslacionVertical);
        //etiqueta.startAnimation(giro);
        //etiqueta.startAnimation(aparicion);
        //etiqueta.startAnimation(escala);

    }
}