package com.example.elementosvarios;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //AUTOCOMPLETE TEXTVIEW
        AutoCompleteTextView campoAutoComplete = findViewById(R.id.autoCompleteTextView);
        //definimos los valores que sugiere
        String[] opciones = {"Opcion1","Opcion2","Tres","OpcionCuatro"};
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,opciones);
        //Asociamos el adaptador al autocompleteTextView
        campoAutoComplete.setAdapter(adaptador);

        //MULTIAUTOCOMPLETE TEXTVIEW
        MultiAutoCompleteTextView campoMultiAutocomplete = findViewById(R.id.multiAutoCompleteTextView);
        String[] opcionesMulti = {"Hoja","Hijo","Hacha","Higo"};
        ArrayAdapter<String> adaptadorMulti = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1,opcionesMulti);
        //añadimos el separador para poder distinguir varias opciones
        campoMultiAutocomplete.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        campoMultiAutocomplete.setAdapter(adaptadorMulti);

        //SPINNER
        //Opicon 1: cargamos los valores desde una lista de XML
        //añadimos la lista a values como "listaValores.xml"
        //en el xml, insertamos "entries" al spinner y seleccionamos la lista

        //Cargamos los valores del xml desde java(pero también se pueden cargar desde un array como antes)
        Spinner combo = findViewById(R.id.spinner);
        //ArrayAdapter<CharSequence> adaptadorSpinner = ArrayAdapter.createFromResource(MainActivity.this, R.array.spinner, android.R.layout.simple_spinner_item);
        //Asociamos el adaptador al elemento de tipo spinner
        //combo.setAdapter(adaptadorSpinner);

        //Opcion 2: cargamos los valores desde un array
        String[]valores = {"Lunes","Martes","Miercoles","Jueves","Viernes"};
        ArrayAdapter<String> adaptadorSpinner = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item,valores);
        combo.setAdapter(adaptadorSpinner);

    }
    
    public void tocado(View view){
        //checkbox
        CheckBox opciones = findViewById(R.id.checkBox);
        if(opciones.isChecked()){
            opciones.setTextColor(getResources().getColor(R.color.azul));
        }else {
            opciones.setTextColor(getResources().getColor(R.color.verde));
        }
    }

}