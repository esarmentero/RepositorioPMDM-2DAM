package com.brunodam.ejemplosintents;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button camara;
    Button telefono;
    Button navegador;
    Button correo;
    Button contacto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Creamos un Intent Implicito, para abrir la camara
        //Primero buscamos el elemento en la vista
        camara = findViewById(R.id.camara);

        //Utilizamos elemento especifico de los botones
        camara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Abrimos Camara
                Intent camara = new Intent("android.media.action.IMAGE_CAPTURE");
                //o se puede hacer con la siguiente sentencia Intent camra = new Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                startActivity(camara);
            }
        });

        //Creamos un intent Implicito para abrir la marcacion automatica
        //Buscamos el elemento en la vista
        telefono = findViewById(R.id.telefono);

        telefono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent telefono = new Intent(Intent.ACTION_DIAL);
                telefono.setData(Uri.parse("tel: +34625487569"));
                startActivity(telefono);
            }
        });

        //Creamos un intent Implicito para abrir el navegador
        //Buscamos el elemento en la vista
        navegador = findViewById(R.id.navegador);

        navegador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //creamos el intent y decimos que ejecute cuando es pulsado
                Intent navegador = new Intent(getIntent().ACTION_VIEW);
                //pasamos la uri que queramos al boton para la accion
                navegador.setData(Uri.parse("http://www.google.es"));
                startActivity(navegador);
            }
        });

        //Creamos un intent Implicito para abrir el correo
        //Buscamos el elemento en la vista
        correo = findViewById(R.id.correo);

        correo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent correo = new Intent(Intent.ACTION_SENDTO);
                // Establecemos la URI a "mailto:", lo que indica que queremos enviar un correo
                correo.setData(Uri.parse("mailto:"));
                // Añadimos la dirección de correo electrónico del destinatario
                correo.putExtra(Intent.EXTRA_EMAIL, new String[]{"ejemplo@gmail.com"});
                // Añadimos un asunto al correo electrónico
                correo.putExtra(Intent.EXTRA_SUBJECT, "ejemplo Asunto");
                startActivity(correo);
            }
        });

        //Creamos un intent Implicito para abrir los contactos
        //Buscamos el elemento en la vista
        contacto = findViewById(R.id.contactos);

        contacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Usamos ACTION_VIEW para mostrar datos
                Intent contacto = new Intent(Intent.ACTION_VIEW);
                // Establecemos la URI de los contactos para abrir la lista de contactos
                contacto.setData(ContactsContract.Contacts.CONTENT_URI);
                startActivity(contacto);
            }
        });

    }

    //metodo para pasar de ventana
    public void pasar(){
        //Intent Explicito (de donde estoy a donde quiero ir)
        Intent next = new Intent(MainActivity.this, EjemploIntent2.class);
        startActivity(next);

    }
    //no se hace solo, asi que tendremos que ir al xml y darle al boton, agregar onClick, y cambiar el codigo por el nombre del metodo

}